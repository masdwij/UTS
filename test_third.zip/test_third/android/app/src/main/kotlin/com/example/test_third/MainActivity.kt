package com.example.test_third

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
